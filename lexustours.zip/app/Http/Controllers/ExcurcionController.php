<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class ExcurcionController extends Controller
{
	public function excurcion()
    {
    	return view('4e/excurciones');
    }
     public function exc1()
    {
    	return view('4e/excurcion/exc1');
    }
    public function exc2()
    {
    	return view('4e/excurcion/exc2');
    }
    public function exc3()
    {
    	return view('4e/excurcion/exc3');
    }
    public function exc4()
    {
    	return view('4e/excurcion/exc4');
    }
    public function exc5()
    {
    	return view('4e/excurcion/exc5');
    }
    public function exc6()
    {
    	return view('4e/excurcion/exc6');
    }
    public function exc7()
    {
    	return view('4e/excurcion/exc7');
    }
    public function exc8()
    {
    	return view('4e/excurcion/exc8');
    }
    public function exc9()
    {
    	return view('4e/excurcion/exc9');
    }
    public function exc10()
    {
    	return view('4e/excurcion/exc10');
    }
    
}
