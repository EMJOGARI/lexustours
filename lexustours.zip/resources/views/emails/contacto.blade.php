<!DOCTYPE html>
<html lang="en">
<head>	
</head>
<body>

	<p>Nombre del Contacto: {{ $name }}</p>
	<p>{{ $tlf }} </p>
	<p>{{ $email }} </p>
	<p>{{ $pais }} </p>
	<p>{{ $adulto }} </p>
	<p>{{ $ninos }} </p>
	<p>{{ $destino }} </p>
	<p>{{ $checkin }} </p>
	<p>{{ $checkout }} </p>
	<p>{{ $msj }} </p>
</body>
</html>