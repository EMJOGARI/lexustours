<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">	
</head>
<body>
		<h1>Su mensaje a sido enviado con exito</h1>
		<p>se respondera en las proximas 48 Horas</p>
</body>
</html>