                      
    <?php echo Form::open(
        [
            'route'  => 'email.store',
            'method' => 'POST', 
            'style'  => 'font-size: .8rem'
        ]); ?> 
                          
        <dix class="row">
            <div class="col-lg-12" style="margin-top: 1rem;"></div>
            <div class="col-md-6">
                <div class="form-group">
                    <?php echo Form::label('name', 'Nombres y Apellidos *'); ?>

                    <?php echo Form::text('name', null, ['class' => 'form-control', 'placeholder' => 'Nombres y Apellidos', 'required']); ?>

                </div>
            </div>

            <div class="col-md-6">
                <div class="form-group">
                    <?php echo Form::label('tlf', 'Telefono *'); ?>

                    <?php echo Form::text('tlf', null, ['class' => 'form-control', 'placeholder' => 'Telefono para Contactarlo', 'required']); ?>

                </div>
            </div>

            <div class="col-md-6">
                <div class="form-group">
                    <?php echo Form::label('email', 'Correo Electronico *'); ?>

                    <?php echo Form::email('email', null, ['class' => 'form-control', 'placeholder' => 'Hoteles@lexustours.com', 'required']); ?>

                </div>
            </div>

            <div class="col-md-6">
                <div class="form-group">
                    <?php echo Form::label('pais', 'Pais *'); ?>

                    <?php echo Form::text('pais', null, ['class' => 'form-control', 'placeholder' => 'Pais donde se Encuetra', 'required']); ?>

                </div>
            </div>

            <div class="col-md-12">
                <div class="form-group">
                    <?php echo Form::label('msj', 'Observaciones'); ?>

                    <?php echo Form::textarea('msj', null, ['class' => 'form-control', 'size' => '30x5']); ?>

                </div>
            </div>
            <div class="col-md-12" style="margin-bottom: 1rem;">
                <div class="row">
                    <div class="col-md-4">             
                        <?php echo Form::submit('Enviar', ['class' => 'btn btn-primary']); ?>

                    </div>                    
                </div>
            </div>                      
        </dix>
    <?php echo Form::close(); ?>

