<?php $__env->startSection('title'); ?>Hoteles <?php $__env->stopSection(); ?>

<?php $__env->startSection('section'); ?><section class="bienvenido hot"> <?php $__env->stopSection(); ?>

<?php $__env->startSection('menu'); ?>
    <ul>
	    <li><a href="<?php echo e(url('/')); ?>">Inicio</a></li>
        <li class="nav-item dropdown active">
            <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Hoteles</a>
            <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                <a class="dropdown-item" href="<?php echo e(url('2h/hoteles')); ?>">Isla de Margarita</a>
                <div class="dropdown-divider"></div>
                <a class="dropdown-item" href="#">Caracas</a>
                <div class="dropdown-divider"></div>
                <a class="dropdown-item" href="#">Los Roque</a>  
            </div>
        </li>
	    <li><a href="<?php echo e(url('3d/destino')); ?>">Destinos</a></li>                        
	    <li><a href="#">Excurciones</a></li> 
	    <li><a href="<?php echo e(url('5b/blog')); ?>">Blog</a></li>                        
	</ul>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('text'); ?>
    <h3 class="display-5">ENCUENTRA EL MEJOR HOTEL DE ACUERDO A TUS NECESIDADES</h3">    
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
	<div class="row">
		<div class="col-md-12">
			<h3 class="display-5"> Hoteles Isla De Margarita</h3">
		</div>
	</div>
	
	
    
<?php $__env->stopSection(); ?>

<?php $__env->startSection('con1'); ?>
	<div class="row">				
		<div class="col-xs-12 col-md-4 " style="height: 300px;">
            <a href="#">
                <div class="card" style="width: 100%; height: 100%;">
                    <img class="card-img" src="<?php echo e(url('/assets/img/hotels/sunsol_punta_blanca.jpg')); ?>" alt="Sunsol Punta Blanca" style="width: 100%; height: 100%;">
                    <div class="card-img-overlay">
                        <h4 class="card-text">Sunsol Punta Blanca</h4>
                        <h6 class="card-text">
                            <i class="fas fa-star"></i>
                            <i class="fas fa-star"></i>
                            <i class="fas fa-star"></i>
                            <i class="fas fa-star"></i>
                            <i class="fas fa-star-half"></i>
                        </h6>
                    </div>
                </div>                            
            </a>                
        </div>  
        <div class="col-xs-12 col-md-4 " style="height: 300px;">
            <a href="#">
                <div class="card" style="width: 100%; height: 100%;">
                    <img class="card-img" src="<?php echo e(url('/assets/img/hotels/sunsol_punta_blanca.jpg')); ?>" alt="Sunsol Punta Blanca" style="width: 100%; height: 100%;">
                    <div class="card-img-overlay">
                        <h4 class="card-text">Sunsol Punta Blanca</h4>
                        <h6 class="card-text">
                            <i class="fas fa-star"></i>
                            <i class="fas fa-star"></i>
                            <i class="fas fa-star"></i>
                            <i class="fas fa-star"></i>
                            <i class="fas fa-star-half"></i>
                        </h6>
                    </div>
                </div>                            
            </a>                
        </div>  
        <div class="col-xs-12 col-md-4 " style="height: 300px;">
            <a href="#">
                <div class="card" style="width: 100%; height: 100%;">
                    <img class="card-img" src="<?php echo e(url('/assets/img/hotels/sunsol_punta_blanca.jpg')); ?>" alt="Sunsol Punta Blanca" style="width: 100%; height: 100%;">
                    <div class="card-img-overlay">
                        <h4 class="card-text">Sunsol Punta Blanca</h4>
                        <h6 class="card-text">
                            <i class="fas fa-star"></i>
                            <i class="fas fa-star"></i>
                            <i class="fas fa-star"></i>
                            <i class="fas fa-star"></i>
                            <i class="fas fa-star-half"></i>
                        </h6>
                    </div>
                </div>                            
            </a>                
        </div>  
    </div>
        
<?php $__env->stopSection(); ?> 


<?php $__env->startSection('con2'); ?>

<?php $__env->stopSection(); ?> 


<?php echo $__env->make('layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>