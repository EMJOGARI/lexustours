<?php $__env->startSection('title'); ?>Hoteles <?php $__env->stopSection(); ?>

<?php $__env->startSection('section'); ?><section class="bienvenido hot"> <?php $__env->stopSection(); ?>

<?php $__env->startSection('menu'); ?>
    <ul>
	    <li><a href="<?php echo e(url('/')); ?>">Inicio</a></li>
	    <li class="active"><a href="<?php echo e(url('2h/hoteles')); ?>">Hoteles</a></li>
	    <li><a href="#">Destinos</a></li>                        
	    <li><a href="#">Excurciones</a></li> 
	    <li><a href="<?php echo e(url('4b/blog')); ?>">Blog</a></li>                        
	</ul>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('text'); ?>
    <h3 class="display-5">ENCUENTRA EL MEJOR HOTEL DE ACUERDO A TUS NECESIDADES</h3">    
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
	<div class="row">
		<div class="col-md-12">
			<h3 class="display-5"> Hoteles Isla De Margarita</h3">
		</div>
	</div>
	
	
    
<?php $__env->stopSection(); ?>

<?php $__env->startSection('con1'); ?>
	<div class="row">				
		<div class="col-xs-12 col-md-4 col-lg-3" style="height: 300px;">            	      
            <a href="#">
                <div class="card">
                    <img class="card-img" src="<?php echo e(url('/assets/img/hotels/sunsol_punta_blanca.jpg')); ?>" alt="Sunsol Punta Blanca">
                    <div class="card-img-overlay">
                        <h4 class="card-text">Sunsol Punta Blanca</h4>
                        <h6 class="card-text">
                            <i class="fas fa-star"></i>
                            <i class="fas fa-star"></i>
                            <i class="fas fa-star"></i>
                            <i class="fas fa-star"></i>
                            <i class="fas fa-star-half"></i>
                        </h6>
                    </div>
                </div>                            
            </a>                
        </div>  
    </div>
        
<?php $__env->stopSection(); ?> 


<?php $__env->startSection('con2'); ?>

<?php $__env->stopSection(); ?> 


<?php echo $__env->make('layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>