<?php $__env->startSection('text'); ?><h2 class="display-4"></h2"> <?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <div class="col-xs-12 col-md-12">
        <h2 class="font-weight-bold">ISLA AVENTURA</h2>
        <hr>        
    </div>         
    <div class="col-xs-12 col-md-8 offset-md-2">        
        <p>Cómodas unidades (van o autobuses) con guía profesional y conductor. Se comienza visitando La Asunción, su Catedral y el centro artesanal, El Castillo de Santa Rosa, continuando a la Basílica de la Virgen del Valle, de allí nos dirigimos hada la Laguna de la Restinga donde realizamos el paseo en lancha por los manglares. Parada para almorzar en Restaurante típico ubicado a orilla de la Playa donde podrán disfrutar alrededor de una hora de la misma. Luego, al regreso, disfrutaremos de uno de los encantos de la isla como son los atardeceres en Juan Griego.</p>
    </div>   

<?php $__env->stopSection(); ?>

<?php $__env->startSection('con1'); ?>
    <ul class="col-xs-6 col-lg-6 text-xs-center text-lg-left">            
        <li>
            <i class="fas fa-coffee" aria-hidden="true"></i>
            <div class="contenedor-eleccion">
                <h4>Refrigerios durante la travesía.</h4>
            </div>
        </li>
        <li>
            <i class="fas fa-utensils"></i>
            <div class="contenedor-eleccion">
                <h4>Almuerzo en la playa.</h4>
            </div>
        </li>
         <li>
            <i class="fas fa-beer"></i>
            <div class="contenedor-eleccion">
                <h4>Bebidas Nacionales.</h4>
            </div>
        </li>        
    </ul>    

    <ul class="col-xs-6 col-lg-6 text-xs-center text-lg-right">
        <li>
            <i class="fas fa-bus" aria-hidden="true"></i>
            <div class="contenedor-eleccion">
                <h4>Entrada al Parque Nacional la Restinga.</h4>
            </div>
        </li>        
        <li>
            <i class="fas fa-ship" aria-hidden="true"></i>
            <div class="contenedor-eleccion">
                <h4>Paseo en lancha por la Restinga.</h4>
            </div>
        </li>        
    </ul>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('extra'); ?>

<ul class="col-xs-12 col-lg-12">
    <li>
        <i class="far fa-check-square" aria-hidden="true"></i>
        <div class="contenedor-eleccion">
            <h4>Ropa ligera, toalla, vestido de baño, protector solar.</h4>
        </div>
    </li>        
    <li>
        <i class="far fa-check-square" aria-hidden="true"></i>
        <div class="contenedor-eleccion">
            <h4>Niños: O a 3 años = Gratis / 4 a 11 años = 50 % descuento.</h4>
        </div>
    </li>        
</ul>

            
            
    
<?php $__env->stopSection(); ?> 

<?php $__env->startSection('con2'); ?>    
    
    <div class="carousel-item active">
        <img class="d-block w-100" src="<?php echo e(url('/assets/img/hotels/margarita/dunes/d01.jpg')); ?>">
    </div>

    <div class="carousel-item">
        <img class="d-block w-100" src="<?php echo e(url('/assets/img/hotels/margarita/dunes/d02.jpg')); ?>">
    </div>

    <div class="carousel-item">
        <img class="d-block w-100" src="<?php echo e(url('/assets/img/hotels/margarita/dunes/d03.jpg')); ?>">
    </div>

    <div class="carousel-item">
        <img class="d-block w-100" src="<?php echo e(url('/assets/img/hotels/margarita/dunes/d04.jpg')); ?>">
    </div>

    <div class="carousel-item">
        <img class="d-block w-100" src="<?php echo e(url('/assets/img/hotels/margarita/dunes/d05.jpg')); ?>">
    </div>                         
                
<?php $__env->stopSection(); ?> 

<?php $__env->startSection('hidden'); ?><?php echo Form::hidden('destino', 'ISLA AVENTURA'); ?> <?php $__env->stopSection(); ?>
<?php echo $__env->make('layout-exc', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>