<?php $__env->startSection('title'); ?>Agua Dorada Beach <?php $__env->stopSection(); ?>

<?php $__env->startSection('section'); ?><section class="bienvenido lad" id="tama"> <?php $__env->stopSection(); ?>

<?php $__env->startSection('text'); ?><h2 class="display-4">Agua Dorada Beach</h2"><?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <div class="col-xs-12 col-md-12">
        <h2>Agua Dorada Beach</h2>
        <hr>        
    </div>         
    <div class="col-xs-12 col-md-7">        
        <p>se constituye en la mejor opción de hospedaje frente a Playa El Agua, Isla de Margarita. Con 84 habitaciones dobles, tiene además dos suites presidenciales, todas decoradas bajo un concepto moderno y minimalista. Todas cuentan con kichinette, servicio de internet, televisión plana y baño privado, entre otras comodidades.</p> 

        <p>En sus amplias áreas sociales –donde llama la atención el uso de la piedra coralina- destaca su piscina y restaurante, que ofrece exquisitos platos de la cocina margariteña e internacional, además de deliciosos cócteles. Asimismo, el Hotel Agua Dorada brinda servicio de toldos, sillas, toallas y servicio de mesoneros a los huéspedes que disfrutan del mar y la arena. Ubicado a 40 minutos (aproximadamente), este hotel de playa cuenta con el respaldo de la cadena Lidotel Hoteles Boutique.</p>
        
    </div>
    <div class="col-xs-12 col-md-5">
    	<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3914.5019572205033!2d-63.87173968483323!3d11.15042199206838!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x8c319428c5302ead%3A0xed7c13abe6e361!2sAgua+Dorada+Beach+Hotel+By+Lidotel!5e0!3m2!1ses-419!2sve!4v1523735692154" width="600" height="450" frameborder="0" style="border:0; width: 100%" allowfullscreen></iframe>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('con1'); ?>
	                   
    <li><i class="fas fa-wifi"></i> Wifi.</li>
    <li><i class="far fa-life-ring"></i> Piscina.</li>
    <li><i class="fas fa-tv"></i> TV Satelital.</li>
    <li><i class="fas fa-utensils"></i> Restaurant.</li>
    <li><i class="fas fa-car"></i> Parking.</li>
    <li><i class="fas fa-plane"></i> Traslado al Aeropuerto.</li>
    <li><i class="fas fa-ship"></i> Traslado al Puerto.</li>
                   
<?php $__env->stopSection(); ?> 

<?php $__env->startSection('con2'); ?>    
    
               

                <div class="carousel-item">
                    <img class="d-block w-100" src="<?php echo e(url('/assets/img/hotels/margarita/lidotelaguadorada/lad02.jpg')); ?>">
                </div>
                 <div class="carousel-item active">
                    <img class="d-block w-100" src="<?php echo e(url('/assets/img/hotels/margarita/lidotelaguadorada/lad01.jpg')); ?>">
                </div>

                <div class="carousel-item">
                    <img class="d-block w-100" src="<?php echo e(url('/assets/img/hotels/margarita/lidotelaguadorada/lad03.jpg')); ?>">
                </div>

                <div class="carousel-item">
                    <img class="d-block w-100" src="<?php echo e(url('/assets/img/hotels/margarita/lidotelaguadorada/lad04.jpg')); ?>">
                </div>

                <div class="carousel-item">
                    <img class="d-block w-100" src="<?php echo e(url('/assets/img/hotels/margarita/lidotelaguadorada/lad05.jpg')); ?>">
                </div> 

                 <div class="carousel-item">
                    <img class="d-block w-100" src="<?php echo e(url('/assets/img/hotels/margarita/lidotelaguadorada/lad06.jpg')); ?>">
                </div>
                 <div class="carousel-item">
                    <img class="d-block w-100" src="<?php echo e(url('/assets/img/hotels/margarita/lidotelaguadorada/lad07.jpg')); ?>">
                </div>              
                
<?php $__env->stopSection(); ?>

<?php $__env->startSection('hidden'); ?><?php echo Form::hidden('destino', 'Lidotel Agua Dorada'); ?> <?php $__env->stopSection(); ?>


<?php echo $__env->make('layout-hotels', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>