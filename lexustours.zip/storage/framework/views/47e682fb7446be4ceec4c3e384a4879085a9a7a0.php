<?php $__env->startSection('title'); ?>Full Day <?php $__env->stopSection(); ?>

<?php $__env->startSection('text'); ?><h2 class="display-4"></h2"> <?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <div class="col-xs-12 col-md-12">
        <h2 class="font-weight-bold">FULL DAY ISLA DE COCHE</h2>
        <hr>        
    </div>         
    <div class="col-xs-12 col-md-8 offset-md-2">        
        <p>Disfrute a bordo de un barco Catamaran o Velero, un día con todo induido a la paradisíaca Isla de Coche, donde encontrará excelentes playas, y podrán disfrutar de un emocionante día de actividades para la animación y recreación del pasajero. Disfrute de bar abierto y un almuerzo en una churuata de playa.</p> 
    </div>   

<?php $__env->stopSection(); ?>

<?php $__env->startSection('con1'); ?>
    <ul class="col-xs-6 col-lg-6 text-xs-center text-lg-left">            
        <li>
            <i class="fas fa-coffee" aria-hidden="true"></i>
            <div class="contenedor-eleccion">
                <h4>Desayuno Ligero.</h4>
            </div>
        </li>
        <li>
            <i class="fas fa-utensils"></i>
            <div class="contenedor-eleccion">
                <h4>Almuerzo</h4>
            </div>
        </li>
         <li>
            <i class="fas fa-beer"></i>
            <div class="contenedor-eleccion">
                <h4>Bebidas nacionales.</h4>
            </div>
        </li>
        <li>
            <i class="far fa-sun" aria-hidden="true"></i>
            <div class="contenedor-eleccion">
                <h4>Sillas y toldos en la playa.</h4>
            </div>
        </li>
    </ul>    

    <ul class="col-xs-6 col-lg-6 text-xs-center text-lg-right">
        <li>
            <i class="fas fa-bus" aria-hidden="true"></i>
            <div class="contenedor-eleccion">
                <h4>Traslados hotel / muelle / hotel.</h4>
            </div>
        </li>        
        <li>
            <i class="fas fa-ship" aria-hidden="true"></i>
            <div class="contenedor-eleccion">
                <h4>Bar abierto con animación a bordo</h4>
            </div>
        </li>
        <li>
            <i class="fas fa-trophy" aria-hidden="true"></i>
            <div class="contenedor-eleccion">
                <h4>Actividades de playa y juegos recreativos.</h4>
            </div>
        </li>
    </ul>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('extra'); ?>

<ul class="col-xs-12 col-lg-12">
    <li>
        <i class="far fa-check-square" aria-hidden="true"></i>
        <div class="contenedor-eleccion">
            <h4>Vestido de baño, toallas, protector solar, sandalias o zapatos playeros.</h4>
        </div>
    </li>        
    <li>
        <i class="far fa-check-square" aria-hidden="true"></i>
        <div class="contenedor-eleccion">
            <h4>Niños: O a 3 años = Gratis /4 a 11 años = 50 % descuento.</h4>
        </div>
    </li>        
</ul>

            
            
    
<?php $__env->stopSection(); ?> 

<?php $__env->startSection('con2'); ?>    
    
    <div class="carousel-item active">
        <img class="d-block w-100" src="<?php echo e(url('/assets/img/hotels/margarita/dunes/d01.jpg')); ?>">
    </div>

    <div class="carousel-item">
        <img class="d-block w-100" src="<?php echo e(url('/assets/img/hotels/margarita/dunes/d02.jpg')); ?>">
    </div>

    <div class="carousel-item">
        <img class="d-block w-100" src="<?php echo e(url('/assets/img/hotels/margarita/dunes/d03.jpg')); ?>">
    </div>

    <div class="carousel-item">
        <img class="d-block w-100" src="<?php echo e(url('/assets/img/hotels/margarita/dunes/d04.jpg')); ?>">
    </div>

    <div class="carousel-item">
        <img class="d-block w-100" src="<?php echo e(url('/assets/img/hotels/margarita/dunes/d05.jpg')); ?>">
    </div>                         
                
<?php $__env->stopSection(); ?> 

<?php $__env->startSection('hidden'); ?><?php echo Form::hidden('destino', 'FULL DAY ISLA DE COCHE'); ?> <?php $__env->stopSection(); ?>
<?php echo $__env->make('layout-exc', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>