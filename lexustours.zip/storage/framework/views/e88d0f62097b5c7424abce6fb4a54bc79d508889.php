<?php $__env->startSection('title'); ?>Kokobay <?php $__env->stopSection(); ?>

<?php $__env->startSection('section'); ?><section class="bienvenido kokobay" id="tama"> <?php $__env->stopSection(); ?>

<?php $__env->startSection('text'); ?><h2 class="display-4">Kokobay</h2"><?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <div class="col-xs-12 col-md-12">
        <h2>Kokobay</h2>
        <hr>        
    </div>         
    <div class="col-xs-12 col-md-7">        
        <p>Un encantador hotel con Todo Incluido. Su principal objetivo es de ofrecer una experiencia inolvidable en una de las playas más bellas de la Isla de Margarita, acompañado de la acogedora hospitalidad que representa al venezolano.</p> 

        <p>Está ubicado en el extremo oriental de Playa Caribe, en Juan Griego. Con una espectacular salida a una playa de arenas blanquecinas, tres restaurantes y un bar con vista al mar que dará la bienvenida al principio de sus vacaciones.</p>

        <p><strong>Plan Todo Incluido:</strong> Desayunos, almuerzos, y cenas Tipo Buffet, bebidas nacionales alcohólicas y no alcohólicas ilimitadas, entretenimiento diurno y nocturno, snacks, sillas y toldos en la playa y piscina.</p>        
        
    </div>
    <div class="col-xs-12 col-md-5">
    	<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2798.3422374167394!2d-63.95982683870624!3d11.108866621799498!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x8c31ecb4b4a84e07%3A0x24b7447492858d28!2sHotel+Kokobay!5e0!3m2!1ses-419!2sve!4v1523737960708" width="600" height="450" frameborder="0" style="border:0; width: 100%" allowfullscreen></iframe>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('con1'); ?>
	                   
    <li><i class="fas fa-wifi"></i> Wifi.</li>
    <li><i class="far fa-life-ring"></i> Piscina.</li>
    <li><i class="fas fa-tv"></i> TV Satelital.</li>
    <li><i class="fas fa-utensils"></i> Restaurant.</li>
    <li><i class="fas fa-car"></i> Parking.</li>
    <li><i class="fas fa-plane"></i> Traslado al Aeropuerto.</li>
    <li><i class="fas fa-ship"></i> Traslado al Puerto.</li>
                   
<?php $__env->stopSection(); ?> 

<?php $__env->startSection('con2'); ?>    
    
                <div class="carousel-item active">
                    <img class="d-block w-100" src="<?php echo e(url('/assets/img/hotels/margarita/Kokobay/kok01.jpg')); ?>">
                </div>

                <div class="carousel-item">
                    <img class="d-block w-100" src="<?php echo e(url('/assets/img/hotels/margarita/Kokobay/kok02.jpg')); ?>">
                </div>

                <div class="carousel-item">
                    <img class="d-block w-100" src="<?php echo e(url('/assets/img/hotels/margarita/Kokobay/kok03.jpg')); ?>">
                </div>

                <div class="carousel-item">
                    <img class="d-block w-100" src="<?php echo e(url('/assets/img/hotels/margarita/Kokobay/kok04.jpg')); ?>">
                </div>

                <div class="carousel-item">
                    <img class="d-block w-100" src="<?php echo e(url('/assets/img/hotels/margarita/Kokobay/kok05.jpg')); ?>">
                </div>            
                
<?php $__env->stopSection(); ?>

<?php $__env->startSection('hidden'); ?><?php echo Form::hidden('destino', 'Kokobay'); ?> <?php $__env->stopSection(); ?>


<?php echo $__env->make('layout-hotels', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>