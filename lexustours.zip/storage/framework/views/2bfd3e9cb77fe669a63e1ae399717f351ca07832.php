<?php $__env->startSection('title'); ?>Política de Privacidad <?php $__env->stopSection(); ?>

<?php $__env->startSection('section'); ?><section class="bienvenido politica" id="tama"> <?php $__env->stopSection(); ?>

<?php $__env->startSection('text'); ?>
    <h1 class="display-4">Política de Privacidad</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
	

<?php $__env->stopSection(); ?>

<?php $__env->startSection('con1'); ?>

<?php $__env->stopSection(); ?> 


<?php $__env->startSection('con2'); ?>	



<?php $__env->stopSection(); ?> 

<?php $__env->startSection('con3'); ?>
	
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>