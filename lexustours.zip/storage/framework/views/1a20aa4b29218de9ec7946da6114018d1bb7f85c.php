<!DOCTYPE html>
<html lang="en">
<head>	
</head>
<body>

	<p>Nombre del Contacto: <?php echo e($name); ?></p>
	<p><?php echo e($tlf); ?> </p>
	<p><?php echo e($email); ?> </p>
	<p><?php echo e($pais); ?> </p>
	<p><?php echo e($adulto); ?> </p>
	<p><?php echo e($ninos); ?> </p>
	<p><?php echo e($destino); ?> </p>
	<p><?php echo e($checkin); ?> </p>
	<p><?php echo e($checkout); ?> </p>
	<p><?php echo e($msj); ?> </p>
</body>
</html>