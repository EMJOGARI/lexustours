<?php $__env->startSection('text'); ?><h2 class="display-4"></h2"> <?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <div class="col-xs-12 col-md-12">
        <h2 class="font-weight-bold">TOURS DE COMPRAS</h2>
        <hr>        
    </div>         
    <div class="col-xs-12 col-md-8 offset-md-2">        
        <p>ESPERANDO INFORMACION</p>
 
    </div>   

<?php $__env->stopSection(); ?>

<?php $__env->startSection('con1'); ?>
    <ul class="col-xs-6 col-lg-4 text-xs-center text-lg-left">
        <li>
            <i class="fas fa-utensils"></i>
            <div class="contenedor-eleccion">
                <h4>Honestidad</h4>
            </div>
        </li>
        <li>
            <i class="fas fa-beer"></i>
            <div class="contenedor-eleccion">
                <h4>Profesionalismo</h4>
            </div>
        </li>
        <li>
            <i class="fas fa-glass-martini" aria-hidden="true"></i>
            <div class="contenedor-eleccion">
                <h4>Servicio</h4>
        </li>
    </ul>

    <div class="hidden-md-down col-lg-4">
        <img src="<?php echo e(url('/assets/img/nuestrosservicios.png')); ?>" alt="Mundo Movil" >
    </div>

    <ul class="col-xs-6 col-lg-4 text-xs-center text-lg-right">
        <li>
            <i class="fas fa-bus" aria-hidden="true"></i>
            <div class="contenedor-eleccion">
                <h4>Actitud abierta y positiva</h4>
            </div>
        </li>        
        <li>
            <i class="far fa-clock" aria-hidden="true"></i>
            <div class="contenedor-eleccion">
                <h4>Puntualidads</h4>
            </div>
        </li>
        <li>
            <i class="fas fa-clipboard-check" aria-hidden="true"></i>
            <div class="contenedor-eleccion">
                <h4>Resultados</h4>
            </div>
        </li>
    </ul>
<?php $__env->stopSection(); ?> 

<?php $__env->startSection('con2'); ?>    
    
                <div class="carousel-item active">
                    <img class="d-block w-100" src="<?php echo e(url('/assets/img/hotels/margarita/dunes/d01.jpg')); ?>">
                </div>

                <div class="carousel-item">
                    <img class="d-block w-100" src="<?php echo e(url('/assets/img/hotels/margarita/dunes/d02.jpg')); ?>">
                </div>

                <div class="carousel-item">
                    <img class="d-block w-100" src="<?php echo e(url('/assets/img/hotels/margarita/dunes/d03.jpg')); ?>">
                </div>

                <div class="carousel-item">
                    <img class="d-block w-100" src="<?php echo e(url('/assets/img/hotels/margarita/dunes/d04.jpg')); ?>">
                </div>

                <div class="carousel-item">
                    <img class="d-block w-100" src="<?php echo e(url('/assets/img/hotels/margarita/dunes/d05.jpg')); ?>">
                </div>                         
                
<?php $__env->stopSection(); ?> 

<?php $__env->startSection('hidden'); ?><?php echo Form::hidden('destino', 'TOURS DE COMPRAS'); ?> <?php $__env->stopSection(); ?>
<?php echo $__env->make('layout-exc', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>