<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Document</title>
</head>
<body>
	<h2>laravel</h2>

	<div>
		¡curso web de <?php echo $name; ?>!
	</div>
</body>
</html>