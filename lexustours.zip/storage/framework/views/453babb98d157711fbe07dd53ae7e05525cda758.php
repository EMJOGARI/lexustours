<?php $__env->startSection('title'); ?>LD Suites Punta Playa <?php $__env->stopSection(); ?>

<?php $__env->startSection('section'); ?><section class="bienvenido ldspp" id="tama"> <?php $__env->stopSection(); ?>

<?php $__env->startSection('text'); ?><h2 class="display-4">LD Suites Punta Playa</h2"><?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <div class="col-xs-12 col-md-12">
        <h2>LD Suites Punta Playa</h2>
        <hr>        
    </div>         
    <div class="col-xs-12 col-md-7">        
        <p>El hotel cuenta con suites de dos y tres habitaciones, capacidad desde 4 hasta 6 personas. Todas las Suites son tipo apartamento que incluyen cocina, comedor y terraza, completamente equipados para el máximo disfrute de nuestros huéspedes.</p> 

        <p>El complejo Hotelero presenta una infraestructura moderna, es un nuevo concepto para vacacionar, celebrar y realizar reuniones corporativas y eventos sociales, ofreciendo un servicio con personal altamente calificado.</p>

        <p>LD Suites Punta Playa está ubicado a tan solo 35 minutos del aeropuerto, en la zona norte de la isla, Pedro González a tan solo 30 minutos de las zonas comerciales visitadas por los turistas.</p>

    </div>
    <div class="col-xs-12 col-md-5">
        <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3914.8508183016816!2d-63.92915907919948!3d11.124486337770325!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x8c319362aecf06bf%3A0x9f40a29ee574eb96!2sClub+Punta+Playa+Hotel+%26+Resort!5e0!3m2!1ses-419!2sve!4v1523499751332" width="600" height="450" frameborder="0" style="border:0, width:100%;" allowfullscreen></iframe>    	
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('con1'); ?>
	                   
    <li><i class="fas fa-wifi"></i> Wifi.</li>
    <li><i class="far fa-life-ring"></i> Piscina.</li>
    <li><i class="fas fa-tv"></i> TV Satelital.</li>
    <li><i class="fas fa-utensils"></i> Restaurant.</li>
    <li><i class="fas fa-car"></i> Parking.</li>
    <li><i class="fas fa-plane"></i> Traslado al Aeropuerto.</li>
    <li><i class="fas fa-ship"></i> Traslado al Puerto.</li>
                   
<?php $__env->stopSection(); ?> 

<?php $__env->startSection('con2'); ?>    
    
                <div class="carousel-item active">
                    <img class="d-block w-100" src="<?php echo e(url('/assets/img/hotels/margarita/ldpuntaplaya/ldspp01.jpeg')); ?>">
                </div>

                <div class="carousel-item">
                    <img class="d-block w-100" src="<?php echo e(url('/assets/img/hotels/margarita/ldpuntaplaya/ldspp02.jpeg')); ?>">
                </div>

                <div class="carousel-item">
                    <img class="d-block w-100" src="<?php echo e(url('/assets/img/hotels/margarita/ldpuntaplaya/ldspp03.jpeg')); ?>">
                </div>

                <div class="carousel-item">
                    <img class="d-block w-100" src="<?php echo e(url('/assets/img/hotels/margarita/ldpuntaplaya/ldspp04.jpg')); ?>">
                </div>

                <div class="carousel-item">
                    <img class="d-block w-100" src="<?php echo e(url('/assets/img/hotels/margarita/ldpuntaplaya/ldspp05.jpg')); ?>">
                </div>     

                <div class="carousel-item">
                    <img class="d-block w-100" src="<?php echo e(url('/assets/img/hotels/margarita/ldpuntaplaya/ldspp06.jpeg')); ?>">
                </div>       
                
<?php $__env->stopSection(); ?> 

<?php $__env->startSection('hidden'); ?><?php echo Form::hidden('destino', 'LD Suites Punta Playa'); ?> <?php $__env->stopSection(); ?>


<?php echo $__env->make('layout-hotels', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>