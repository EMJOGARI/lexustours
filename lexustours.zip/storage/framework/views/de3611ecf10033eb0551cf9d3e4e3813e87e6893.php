<!DOCTYPE html>
<html>
    <head>
        <title><?php echo $__env->yieldContent('title'); ?> - Lexus Tours</title>
        <!-- Required meta tags always come first -->
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
        <meta http-equiv="x-ua-compatible" content="ie=edge">
        <link rel="ico" href="favicon.ico">
        <!--CARGA DE FUENTES -->
        <link href="https://fonts.googleapis.com/css?family=Open+Sans:400,700,700i" rel="stylesheet" type="text/css">
        <!--CARGA ARCHIVO OWL CAROUSEL -->
        <?php echo Html::style('/assets/css/owl.carousel.min.css'); ?> 
        <?php echo Html::style('/assets/css/owl.theme.default.min.css'); ?>

        <!--CARGA ARCHIVO ICONOS -->
         <?php echo Html::style('/assets/css/fontawesome-all.css'); ?>

        <!--CARGA ARCHIVO CSS -->
        <?php echo Html::style('/assets/css/bootstrap.css'); ?>

         <?php echo Html::style('/assets/css/animate.min.css'); ?>

        <?php echo Html::style('/assets/css/estilos.css'); ?>


        <style>
            form {
                padding-right: 2rem;
                padding-left:  2rem;
                background: #fff;
            }
        </style>
        
    </head>
    <body class="interna">
        <?php echo $__env->yieldContent('section'); ?>
            <header class="encabezado navbar-fixed-top" role="banner" id="enc">
                <div class="container">
                    <a href="<?php echo e(url('/')); ?>" class="logo">
                        <img src="<?php echo e(url('/assets/img/lexus.png')); ?>" alt="logo empresa">
                    </a>

                    <button type="button" class="boton-menu hidden-md-up" data-toggle="collapse" data-target="#menu-principal" aria-expanded="false">
                    <i class="fa fa-bars" aria-hidden="true"></i>
                    </button>
                        <nav id="menu-principal" class="collapse">                            
                            <ul>
                                <li><a href="<?php echo e(url('/')); ?>">Inicio</a></li>
                                <li class="nav-item dropdown">
                                    <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Hoteles</a>
                                    <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                                        <a class="dropdown-item" href="<?php echo e(url('2h/margarita')); ?>">Isla Margarita</a> 
                                        <a class="dropdown-item" href="<?php echo e(url('2h/coche')); ?>">Isla de Coche</a>
                                        <!--a class="dropdown-item" href="#">Los Roque</a>
                                        <a class="dropdown-item" href="#">Caracas</a>   
                                        <a class="dropdown-item" href="#">Canaima</a-->  
                                    </div>
                                </li>
                                
                                <li class=" active"><a href="<?php echo e(url('3d/destino')); ?>">Destinos</a></li>                        
                                <li><a href="<?php echo e(url('4e/excurciones')); ?>">Excursiones</a></li> 
                                <li><a href="#">Blog</a></li>                        
                            </ul>
                        </nav>       
                </div>
            </header>

            <div class="texto-encabezado text-xs-center">
                <div class="container">
                    <?php echo $__env->yieldContent('text'); ?>
                </div>
            </div>
        </section>

        <!-- contenedor de todo la informacion -->
        <main class="p-y-3 text-justify">
            <div class="container">
                <?php echo $__env->yieldContent('content'); ?>  
            </div>
        </main>

        <section class="container-fluid text-justify con1">
            <?php echo $__env->yieldContent('con1'); ?>  
        </section>

        <section class="form-section text-justify p-y-1" style="background: #EFEFEF;">
            <div class="container">
                <div class="row">
                    <div class="col-xs-12 text-xs-center">
                        <h2><?php echo $__env->yieldContent('destino'); ?></h2>
                        <hr>
                    </div>
                    <div class="col-md-6">
                        <?php echo $__env->yieldContent('mapa'); ?>                        
                    </div>
                    <div class="col-md-6" style="font-size: .8rem;"> 
                        <?php echo $__env->make('form-emails', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                    </div>
                </div>
            </div>
        </section>               

        <footer class="pie-de-pagina" role="contentinfo">
            <div class="container">
                <div class="row">
                    <div class="col-xs-12 col-md-6 col-lg-4">
                        <h3 class="titulo-modulo">Información de contacto</h3>
                        <p>Av. Bolívar, C.C. AB, Nivel PL, Ofic. 21, Playa El Angel, Pampatar, Isla Margarita</p>
                        <ul class="informacion-de-contacto">                        
                            <li>
                                <i class="fa fa-phone"></i> (0295) 262-4933 / 7512 / 9816
                            <li>
                                <i class="fa fa-fax"></i> (0295) 262-9816
                            </li>
                            <li>
                                <i class="fa fa-envelope"></i>
                                <a href="#">Hoteles@lexustours.com</a>
                            </li>

                            </li>
                        </ul>
                        <ul class="redes-sociales">
                            <li><a href="#"><i class="fab fa-twitter-square" aria-hidden="true"></i></a></li>
                            <li><a href="#"><i class="fab fa-facebook-square" aria-hidden="true"></i></a></li>
                            <li><a href="#"><i class="fab fa-instagram" aria-hidden="true"></i></a></li>
                        </ul>
                    </div>

                    <div class="hidden-md-down col-lg-4">
                        <img src="<?php echo e(url('/assets/img/afiliados.png')); ?>" alt="">
                    </div>

                    <div class="col-xs-12 col-md-6 col-lg-4">
                        <h3 class="titulo-modulo">Mayor Informacion</h3>
                        <ul class="nav menu normal-legales">
                            <li class="item-312">
                                <a href="<?php echo e(url('contacto-nosotros/contacto')); ?>">Contacto</a>
                            </li>
                            <li class="item-310">
                                <a href="<?php echo e(url('contacto-nosotros/nosotros')); ?>">Sobre Nosotros</a>
                            </li>                         
                            <li class="item-310">
                                <a href="<?php echo e(url('contacto-nosotros/politicas')); ?>">Politicas de Privacidad</a>
                            </li>                                               
                        </ul>
                    </div>
                </div>
            </div>
            <section class="creditos">
                <div class="container">
                    <div class="text-xs-center">
                        <p>Lexus Tours @2018  | Todos los derechos reservados | RIF: J-30554640-1 | VT: 2335 - RTN: 5020 - RTE: J154 - TTT: 653 </p>
                    </div>
                </div>
            </section>
        </footer>

        <?php echo Html::script('/assets/js/jquery.min.js'); ?>

        <?php echo Html::script('/assets/js/owl.carousel.min.js'); ?>

        <?php echo Html::script('/assets/js/bootstrap.min.js'); ?>

        <?php echo Html::script('/assets/js/wow.min.js'); ?>

        <script type="text/javascript">
            new WOW().init();
        </script>
        <?php echo Html::script('/assets/js/smooth-scroll.min.js'); ?>    
        <?php echo Html::script('/assets/js/codigos.js'); ?>    
    </body>
</html>