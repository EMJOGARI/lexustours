<?php $__env->startSection('title'); ?>LD H2OTEL <?php $__env->stopSection(); ?>

<?php $__env->startSection('section'); ?><section class="bienvenido ldh" id="tama"> <?php $__env->stopSection(); ?>

<?php $__env->startSection('text'); ?><h2 class="display-4">LD H2OTEL</h2"><?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <div class="col-xs-12 col-md-12">
        <h2>LD H2OTEL</h2>
        <hr>        
    </div>         
    <div class="col-xs-12 col-md-7">        
        <p><strong>Este magnífico hotel se encuentra ubicado en la playa más paradisíaca de la Isla de Coche.</strong> A tan solo 20 minutos de navegación de la Isla de Margarita, SUNSOL Punta Blanca es el lugar ideal para disfrutar de unas vacaciones mágicas y memorables. Frente a una hermosa playa de finas arenas blancas y aguas cristalinas, emerge este hotel de categoría 4 estrellas superior, con un <strong>servicio Todo Incluido con bebidas Premium dentro de su paquete.</strong></p> 

        <p><strong>Una majestuosa y relajante piscina de usos múltiples</strong> y borde infinito que se confunde con el mar le espera con áreas para el descanso y actividades dirigidas: cascada, jacuzzi y zona para niños.</p>

        <p>Facilidades en la playa para el alquiler de servicios de velerismo, kite-surf, wind-surf, kayaks, wave-runners y bananas boat.
        Parque Infantil. Mini market. Servicio de toallas y tumbonas en la piscina y en la playa. Actividades diurnas para niños y adultos. WIFI en el área de Recepción. Transporte marítimo entre Playa El Yaque y la Isla de Coche.</p>

        <p><strong>El Hotel ha sido concebido también para el desarrollo de Celebraciones de Bodas y Renovación de Votos.</strong>
        Ofrece un mágico escenario natural donde se combina perfectamente el exclusivo paisajismo caribeño y los más hermosos atardeceres y, junto con la amplia experiencia de su staff en la concepción y ejecución del evento, convierten en realidad uno de los momentos más especiales de su vida.</p>  
        
    </div>
    <div class="col-xs-12 col-md-5">
    	<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3914.5891957889144!2d-63.87080078535811!3d11.143941934797862!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x8c319426b0105263%3A0x16f2ca2320039e06!2sH2otel!5e0!3m2!1ses-419!2sve!4v1523727314177" width="600" height="450" frameborder="0" style="border:0; width: 100%;" allowfullscreen></iframe>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('con1'); ?>
	                   
    <li><i class="fas fa-wifi"></i> Wifi.</li>
    <li><i class="far fa-life-ring"></i> Piscina.</li>
    <li><i class="fas fa-tv"></i> TV Satelital.</li>
    <li><i class="fas fa-utensils"></i> Restaurant.</li>
    <li><i class="fas fa-car"></i> Parking.</li>
    <li><i class="fas fa-plane"></i> Traslado al Aeropuerto.</li>
    <li><i class="fas fa-ship"></i> Traslado al Puerto.</li>
                   
<?php $__env->stopSection(); ?> 

<?php $__env->startSection('con2'); ?>    
    
    <div class="carousel-item active">
        <img class="d-block w-100" src="<?php echo e(url('/assets/img/hotels/margarita/ldh2otel/ldh01.jpeg')); ?>">
    </div>

    <div class="carousel-item">
        <img class="d-block w-100" src="<?php echo e(url('/assets/img/hotels/margarita/ldh2otel/ldh02.jpeg')); ?>">
    </div>

    <div class="carousel-item">
        <img class="d-block w-100" src="<?php echo e(url('/assets/img/hotels/margarita/ldh2otel/ldh03.jpeg')); ?>">
    </div>

    <div class="carousel-item">
        <img class="d-block w-100" src="<?php echo e(url('/assets/img/hotels/margarita/ldh2otel/ldh04.jpeg')); ?>">
    </div>

    <div class="carousel-item">
        <img class="d-block w-100" src="<?php echo e(url('/assets/img/hotels/margarita/ldh2otel/ldh05.jpeg')); ?>">
    </div> 

    <div class="carousel-item">
        <img class="d-block w-100" src="<?php echo e(url('/assets/img/hotels/margarita/ldh2otel/ldh06.jpeg')); ?>">
    </div>

    <div class="carousel-item">
        <img class="d-block w-100" src="<?php echo e(url('/assets/img/hotels/margarita/ldh2otel/ldh07.jpeg')); ?>">
    </div>              
                
<?php $__env->stopSection(); ?>

<?php $__env->startSection('hidden'); ?><?php echo Form::hidden('destino', 'LD H2OTEL'); ?> <?php $__env->stopSection(); ?>


<?php echo $__env->make('layout-hotels', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>