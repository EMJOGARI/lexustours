<?php $__env->startSection('title'); ?>Full Day <?php $__env->stopSection(); ?>

<?php $__env->startSection('text'); ?><h2 class="display-4"></h2"> <?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <div class="col-xs-12 col-md-12">
        <h2 class="font-weight-bold">FULL DAY ISLA DE CUBAGUA</h2>
        <hr>        
    </div>         
    <div class="col-xs-12 col-md-8 offset-md-2">        
        <p>Durante el Full Day a Cubagua contará con traslado desde su hospedaje hasta el embarcadero, donde será recibido por nuestro grupo de recreadores y activistas, quienes ofrecen diversión y un esmerado servicio a bordo. Se sumergirá en una experiencia diferente haciendo snorkeling a un costado de la isla. Podrá disfrutar de refrescantes bebidas y un suculento almuerzo, tomarse fotos y ser testigo de una exuberante vista durante el Paseo Xerófilo o relajarse en nuestro barro terapia.</p> 
    </div>   

<?php $__env->stopSection(); ?>

<?php $__env->startSection('con1'); ?>
    <ul class="col-xs-6 col-lg-6 text-xs-center text-lg-left">            
        <li>
            <i class="fas fa-coffee" aria-hidden="true"></i>
            <div class="contenedor-eleccion">
                <h4>Snack de bienvenida</h4>
            </div>
        </li>
        <li>
            <i class="fas fa-utensils"></i>
            <div class="contenedor-eleccion">
                <h4>Almuerzo en la playa</h4>
            </div>
        </li>
         <li>
            <i class="fas fa-beer"></i>
            <div class="contenedor-eleccion">
                <h4>Bebidas Nacionales.</h4>
            </div>
        </li>
        <li>
            <i class="far fa-sun" aria-hidden="true"></i>
            <div class="contenedor-eleccion">
                <h4>Sillas y toldos en la playa.</h4>
            </div>
        </li>
    </ul>    

    <ul class="col-xs-6 col-lg-6 text-xs-center text-lg-right">
        <li>
            <i class="fas fa-bus" aria-hidden="true"></i>
            <div class="contenedor-eleccion">
                <h4>Traslados hotel / muelle / hotel.</h4>
            </div>
        </li>        
        <li>
            <i class="fas fa-ship" aria-hidden="true"></i>
            <div class="contenedor-eleccion">
                <h4>Música, excelente animación y diversión.</h4>
            </div>
        </li>
        <li>
            <i class="fas fa-trophy" aria-hidden="true"></i>
            <div class="contenedor-eleccion">
                <h4>Actividades Recreativos.</h4>
            </div>
        </li>
        <li>
            <i class="fas fa-trophy" aria-hidden="true"></i>
            <div class="contenedor-eleccion">
                <h4>El mejor snorkeling en ferry hundido.</h4>
            </div>
        </li>
        <li>
            <i class="fas fa-trophy" aria-hidden="true"></i>
            <div class="contenedor-eleccion">
                <h4>Barro terapia</h4>
            </div>
        </li>
    </ul>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('extra'); ?>

<ul class="col-xs-12 col-lg-12">
    <li>
        <i class="far fa-check-square" aria-hidden="true"></i>
        <div class="contenedor-eleccion">
            <h4>Vestido de baño, toallas, protector solar, sandalias o zapatos playeros.</h4>
        </div>
    </li>        
    <li>
        <i class="far fa-check-square" aria-hidden="true"></i>
        <div class="contenedor-eleccion">
            <h4>Niños: O a 3 años = Gratis /4 a 11 años = 50 % descuento.</h4>
        </div>
    </li>        
</ul>

            
            
    
<?php $__env->stopSection(); ?> 

<?php $__env->startSection('con2'); ?>    
    
    <div class="carousel-item active">
        <img class="d-block w-100" src="<?php echo e(url('/assets/img/hotels/margarita/dunes/d01.jpg')); ?>">
    </div>

    <div class="carousel-item">
        <img class="d-block w-100" src="<?php echo e(url('/assets/img/hotels/margarita/dunes/d02.jpg')); ?>">
    </div>

    <div class="carousel-item">
        <img class="d-block w-100" src="<?php echo e(url('/assets/img/hotels/margarita/dunes/d03.jpg')); ?>">
    </div>

    <div class="carousel-item">
        <img class="d-block w-100" src="<?php echo e(url('/assets/img/hotels/margarita/dunes/d04.jpg')); ?>">
    </div>

    <div class="carousel-item">
        <img class="d-block w-100" src="<?php echo e(url('/assets/img/hotels/margarita/dunes/d05.jpg')); ?>">
    </div>                         
                
<?php $__env->stopSection(); ?> 

<?php $__env->startSection('hidden'); ?><?php echo Form::hidden('destino', 'FULL DAY ISLA DE CUBAGUA'); ?> <?php $__env->stopSection(); ?>
<?php echo $__env->make('layout-exc', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>